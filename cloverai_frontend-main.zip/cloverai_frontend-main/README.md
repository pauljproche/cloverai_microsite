Frontend HTML+CSS link: 

https://pauljproche.github.io/cloverai_frontend/
